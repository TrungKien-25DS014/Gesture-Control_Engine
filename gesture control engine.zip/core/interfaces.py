"""
core/interfaces.py

Ranh giới giao tiếp giữa các package (vision, gesture_engine, world, rendering).
Mỗi package chỉ được phép phụ thuộc vào các Protocol/data class ở core/,
không được import trực tiếp implementation của package khác.

vision/          -> GestureEvent (raw) -> gesture_engine/
gesture_engine/  -> GestureEvent (đã phân loại) -> world/
world/           -> list[WorldAnchor] -> rendering/
"""

from __future__ import annotations

from typing import Protocol

from core.gesture_event import GestureEvent
from core.world_anchor import WorldAnchor


class VisionSource(Protocol):
    """vision/: đọc camera, trả về landmark tay đã chuẩn hóa."""

    def read_frame(self) -> GestureEvent | None: ...


class GestureEngine(Protocol):
    """gesture_engine/: nhận raw landmark, sinh GestureEvent có ý nghĩa (pinch/push/...)."""

    def process(self, raw_event: GestureEvent) -> GestureEvent: ...


class WorldLogic(Protocol):
    """world/: nhận GestureEvent, cập nhật danh sách WorldAnchor."""

    def handle_event(self, event: GestureEvent) -> None: ...
    def get_anchors(self) -> list[WorldAnchor]: ...


class Renderer(Protocol):
    """rendering/: nhận danh sách WorldAnchor, vẽ lên màn hình."""

    def render(self, anchors: list[WorldAnchor]) -> None: ...